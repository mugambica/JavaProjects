package com.myshopping;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// means below class must be having a table mapped for it

@Entity  
@Table(name = "SYS_DEPT") //dept is the actual table name
public class Department {
	
	@Id //means below member is a primary key
	@Column(name="DEPTNO")
	private int departmentNumber; //as as per dept table deptno
	
	@Column(name="DNAME",length = 10)
	private String departmentName; // as per dept table dname
	
	@Column(name="LOC", length=10)
	private String departmentLocation; // as per dept table location
	
	public Department() {
		super();
		System.out.println("Department() is called...");
	}

	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentLocation() {
		return departmentLocation;
	}

	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}
	
	
	
	
	
}

