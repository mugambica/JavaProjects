package com.myshopping;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil { // same as kitchen
	
	private static final SessionFactory sessionFactory = buildSessionFactory();
	
	private static SessionFactory buildSessionFactory() 
	{
		Metadata metadata = null;
		try {
			ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().build();
			metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Session factory creation failed...."+e);
		}
		return metadata.getSessionFactoryBuilder().build();
	}
	public static SessionFactory getSessionFactory() {
		return sessionFactory; //the object of line number 11
	}
	public void shutDown() {
		getSessionFactory().close();
	}
}
